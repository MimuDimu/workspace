# RANCANGAN — pchroot (Arch-Only Chroot Sandbox, Rust)

Dokumen ini revisi penuh dari `RANCANGAN-DCHROOT.md` (multi-distro, 4 module shell
diwakili satu binary, spawn `chroot` eksternal). Revisi ini memangkas scope ke
**Arch Linux ARM saja** dan mengganti mekanisme `enter` dari chroot klasik menjadi
sandbox native hasil riset `CHROOT_HANAMA.md` (port `sandbox.c`, lampiran 12.2).

Status: disetujui user (keputusan desain 1–10 + struktur folder, 11 Okt 2026).
Acuan implementasi step-by-step (Part 2 workflow). Kode dan komentar kode selalu
English (ALWAYS-ON Part 0); dokumen ini berbahasa Indonesia.

---

## 1. Konteks

Module KSU lama punya 4 pasang skrip shell (install/setup/enter/uninstall per
distro). Rancangan pertama (`dchroot`) berniat menyatukan keempatnya jadi satu
binary Rust. Revisi ini menyadarkan scope: yang benar-benar dipakai dan sudah
tervalidasi di device real adalah **Arch** — jadi satu binary, satu distro.

Lebih penting lagi: riset `CHROOT_HANAMA.md` sudah membuktikan mekanisme chroot
klasik (mount + `chroot` binary) punya kelemahan struktural — root di dalam
chroot adalah root Android asli, chroot bisa diloloskan proses ber-CAP_SYS_CHROOT.
Mekanisme penggantinya, `sandbox.c`, sudah terbukti jalan penuh di HP dan di-port
ke Rust di sini.

Prinsip porting: **hanya fitur berstatus "Jalan" di riset yang diimplementasi.**
Fitur berstatus dugaan/belum dites tidak masuk (daftar eksplisit di bagian 8).

---

## 2. Keputusan Desain Final

| # | Keputusan | Isi |
|---|---|---|
| 1 | Nama binary | `pchroot`. Bersih dicek: tidak ada tool/repo bernama persis itu; tidak menabrak binary sistem Android/KSU. Catatan risiko publik (dua proyek bernama mirip) tidak relevan untuk pemakaian pribadi ini. |
| 2 | Crate syscall | `libc` polos. Tidak pakai `nix` (API surface lebih besar tanpa kebutuhan; BPF seccomp tetap dibangun manual). |
| 3 | Argumen distro | **Dihapus.** Tidak ada lagi yang didispatch — pemakaian `pchroot enter`, bukan `pchroot enter arch`. |
| 4 | Mount `/sdcard`, `/system` | **Dihapus total** sesuai temuan riset: akses tulis ke keduanya dari dalam chroot membuat `rm -rf` nyasar bisa mengenai data Android (sengaja dicopot di launcher v1.2). Kalau dibutuhkan, user tambahkan sendiri lewat custom mount (aware risiko). |
| 5 | Aturan firewall `ndc` | Terintegrasi di `enter`: tiga chain (`dozable`, `powersave`, `restricted`) di-set `allow` untuk uid 100000 (root) dan `100000 + uid user` (mode user — user inner 1000 berkuid 101000 di mata Android, harus dibuka tersendiri) setiap kali masuk, hasil dicatat ke log file. Flag `--no-firewall` untuk skip. Ini menggantikan wrapper shell `sb` — tidak ada lagi file terpisah yang bisa lupa dijalankan. |
| 6 | `shift` / `unshift` | Jadi subcommand eksplisit (`pchroot shift`, `pchroot unshift`) — port `do_shift()`: marker `.sandbox-copy` wajib, `FTW_DEPTH` (isi dulu, folder induk terakhir sebagai penanda status), bisa dilanjutkan kalau terputus, `unshift` mencetak peringatan pulihkan setuid. |
| 7 | Opsi sandbox | Semua di-port dari `sandbox.c`: `-n`, `--pids N`, `--no-seccomp`, `--keep-caps`, ditambah `--no-firewall` (baru). `-n` ditandai "terbukti di fase shell, flag di program belum dites di HP" di semua dokumen. Fitur tak-terbukti lain **tidak masuk** (bagian 8). |
| 8 | `setup` pakai chroot klasik | Setup tetap mount klasik + `chroot` sebagai root asli. Alasan: `pacman-key` dkk. menulis sebagai root asli; alur riset sendiri menempatkan `--shift` *setelah* setup. Sandbox hanya untuk `enter`. |
| 9 | Konstanta hardcoded | `BASE=100000`, `RANGE=65536`, `AID_INET=3003`, `DEFAULT_PIDS=1024`, path rootfs `/data/local/chroot/arch/rootfs` — konstanta di satu tempat (`arch.rs`), bukan flag. Tidak ada kasus ubah. |
| 10 | Nama subcommand | `install`, `setup`, `shift`, `unshift`, `enter`, `run`, `uninstall`. |
| 11 | Akun user | Setup prompt username (kosong = mode root, backward compatible). `enter` default masuk sebagai user via `setresuid` di child pasca-userns; `--root` / `--user <nama>` override. Password tidak ditanya: tidak ada konsumen password di dalam sandbox, gerbang nyata adalah root Android. Hostname tetap `pcharch` (di-set pchroot via `sethostname`, bukan urusan Arch). |
| 12 | Subcommand `run` | Jalankan satu perintah di sandbox tanpa shell interaktif: `pchroot run [--root] -- <cmd...>` (default root; `--user <nama>` juga tersedia). stdout/stderr child ter-inherit ke terminal (output langsung tampil), exit code perintah diteruskan ke Termux. Tujuan: tugas root ringkas (`pacman -Syu`, dst.) tanpa keluar-masuk mode enter. |

Riwayat keputusan lama yang **dibatalkan** oleh revisi ini (supaya tidak dihidupkan
lagi): spawn `Command::new("chroot")` untuk `enter`; trait `DistroSetup`;
subcommand per-distro; "recommended packages" hardcoded (sudah diganti custom
packages bebas di rancangan lama, tetap berlaku).

---

## 3. Dependencies

| Kebutuhan | Crate |
|---|---|
| Parse CLI (subcommand + flag) | `clap` v4, features `["derive"]` |
| HTTP download rootfs | `ureq` v2 (blocking; tool sekuensial murni, async overkill) |
| Syscall namespace/seccomp/prctl | `libc` |

Tidak ada: `nix`, `serde`, `anyhow`/`thiserror`, `indicatif`. Error handling satu
enum manual di `error.rs` (CLI-SCHEMA bagian 6).

```toml
[dependencies]
clap = { version = "4", features = ["derive"] }
ureq = "2"
libc = "0.2"
```

---

## 4. Struktur Folder

### 4.1 Code Rust

```
pchroot/
├── Cargo.toml
└── src/
    ├── main.rs            # thin entry: parse clap -> run() -> print/exit code
    ├── lib.rs             # public orchestration (callable from tests/)
    ├── error.rs           # one AppError enum for the whole app
    ├── cli.rs             # clap derive: 7 subcommands + flag validation
    ├── arch.rs            # pacman.conf fixes, setup steps, default URL, constants
    ├── shift.rs           # port of do_shift(): nftw + marker + resumable
    ├── sandbox/
    │   ├── mod.rs
    │   ├── child.rs       # child_main: mounts, pivot_root, drop uid, userns, exec
    │   ├── parent.rs      # clone, pipe handshake, write uid/gid_map, wait
    │   ├── seccomp.rs     # build BPF denylist filter + install
    │   └── cgroup.rs      # pids controller join + cleanup
    └── commands/
        ├── mod.rs
        ├── install.rs     # ureq download + extract + validate + resolv.conf
        ├── setup.rs       # classic mounts + numbered steps + custom mounts/packages prompts
        ├── enter.rs       # ndc firewall rules + sandbox spawn
        ├── run.rs         # sandbox spawn + execve perintah sekali jalan
        └── uninstall.rs
tests/
    └── integration_test.rs
```

Aturan per CLI-SCHEMA: `main.rs` tetap tipis (parse, satu panggilan orkestrasi,
print hasil, exit code); business logic di `lib.rs`/`commands/`; satu error enum;
error ke stderr dengan format `error: <message>`; exit code 0 sukses, 1 gagal;
stdout hanya untuk output sukses.

### 4.2 Module KSU

```
pchroot-module/
├── module.prop           # id=pchroot, versionCode=1
├── customize.sh          # aarch64 check + set_perm binary
└── system/
    └── bin/
        └── pchroot       # cross-compile target aarch64-linux-android
```

Tidak ada `service.sh` (auto-ndc tiap boot, gap 2 riset) — sengaja di luar scope;
keputusan #5 sudah menutup kebutuhan harian.

---

## 5. Interface CLI

```
pchroot install    [--url <url>] [--yes]
pchroot setup      [--yes]
pchroot shift
pchroot unshift
pchroot enter      [-n] [--pids N] [--no-seccomp] [--keep-caps] [--no-firewall]
                   [--root | --user <nama>]
pchroot run        [-n] [--pids N] [--no-seccomp] [--keep-caps] [--no-firewall]
                   [--root | --user <nama>] -- <cmd...>
pchroot uninstall  [--yes]
```

- Semua command wajib root (cek `geteuid() != 0` di tiap command, pola shell lama).
- Prompt interaktif dengan fallback flag: flag ada → pakai nilai flag, skip prompt;
  flag tidak ada → prompt stdin seperti shell lama.
- `--yes` melewati konfirmasi/konfirmasi-pakai-default. Angka `--pids` default 1024.

Heading output (`ARCH INSTALLATION`, `ARCH SETUP`, dst.) digenerate dari satu
fungsi format `heading("ARCH", "INSTALLATION")`, bukan diketik ulang per command.

---

### 5.1 Lokasi File State

Semua state pchroot terpusat di base path `/data/local/chroot/arch/`, kecuali log dan
cgroup sementara:

| File | Lokasi | Dibuat oleh | Catatan |
|---|---|---|---|
| Tarball download | `arch/downloads/` | install | |
| Rootfs | `arch/rootfs/` | install | |
| `resolv.conf` | `rootfs/etc/resolv.conf` | install | wajib di dalam rootfs — dibaca resolver di dalam chroot |
| `.initialized` | `arch/.initialized` | setup | di luar rootfs supaya proses di dalam sandbox tidak bisa mengutak-atik flag host |
| `.custom_mounts` | `arch/.custom_mounts` | setup | dibaca `enter` tiap masuk |
| `.user` | `arch/.user` | setup | username untuk masuk non-root; tidak ada = mode root |
| `.sandbox-copy` | `rootfs/.sandbox-copy` | user (manual) | sengaja di dalam rootfs — marker harus ikut kalau rootfs di-`cp -a`, dan dia menandai folder yang memang mau digeser |
| Log firewall | `/data/local/tmp/pchroot.log` | enter | tidak dihapus uninstall |
| cgroup sementara | `/sys/fs/cgroup/pcharch-<pid>` | enter | dihapus otomatis saat keluar |

---

## 6. Mekanisme Per Subcommand

### 6.1 `pchroot install`

Murni download + extract + validasi (tidak ada mount, tidak menyentuh sistem).

1. Prompt URL (default `http://os.archlinuxarm.org/os/ArchLinuxARM-aarch64-latest.tar.gz`).
2. Cek URL (HEAD/GET range), tampilkan estimasi ukuran.
3. Cek sisa disk `/data` (butuh ~2x ukuran tarball).
4. Download via `ureq` ke `/data/local/chroot/arch/downloads/`, output teks persen:
   `Downloaded: 89 MB / 178 MB (50%)`.
5. Extract `tar -xzf` (spawn `tar`, bukan `bsdtar`) ke `/data/local/chroot/arch/rootfs`.
6. Validasi `/usr/bin/bash` ada (arch-check binary Arch; bukan `/bin/bash`).
7. `rm -f /etc/resolv.conf` dulu — symlink bawaan menunjuk ke systemd-resolved yang
   belum ada; `cat >` tanpa rm gagal `No such file or directory` — lalu tulis statis
   `8.8.8.8`, `8.8.4.4`, `1.1.1.1`.
8. Output: `Install... Done` + `Next step: pchroot setup`.

### 6.2 `pchroot setup`

Chroot klasik sebagai root asli, dijalankan sekali (guard `arch/.initialized`).

1. Guard: root, rootfs sudah install, `/data/local/chroot/arch/.initialized` belum ada.
2. Unmount sisa mount sesi lama (loop 5 titik: `dev/pts dev/shm dev sys proc`).
3. Mount klasik: bind `/dev`, `/dev/shm`, devpts, bind `/sys`, procfs baru ke rootfs.
4. Prompt custom mount points (pola 2-baris `Host path:` / `Chroot path:`), simpan ke
   `/data/local/chroot/arch/.custom_mounts` (format `host_path|chroot_path` per baris, dibaca `enter`).
5. Prompt username untuk sandbox (kosong = mode root seperti semula; diisi = `useradd -m -G wheel -s /bin/bash <nama>` di step `[2/7]` + tulis `arch/.user`). Password tidak ditanya: gerbang nyata adalah root Android, tidak ada konsumen password di dalam sandbox.
6. Prompt custom packages (kosong = skip total, bukan error).
7. Di dalam chroot, langkah bernomor fatal-aware:
   - `[1/7] Creating network groups...` — `groupadd aid_inet/aid_net_raw/aid_graphics`, `usermod -aG aid_inet root`
   - `[2/7] Creating user <nama>...` — `useradd -m -G wheel -s /bin/bash <nama>`; skip kalau username kosong
   - `[3/7] Disabling CheckSpace, sandbox, and signature checks...` — 3 fix `pacman.conf`: comment `CheckSpace`; tambah `DisableSandbox` di `[options]` (Landlock tidak didukung kernel Android, pacman 7+); `SigLevel = Never` (GPGME gagal di chroot Android — trade-off disetujui untuk chroot CLI). Ketiganya fatal: gagal tulis = abort.
   - `[4/7] Initializing pacman keyring...` — `rm -rf /etc/pacman.d/gnupg` → `pacman-key --init` → `pacman-key --populate archlinuxarm` → `pacman-key --refresh-keys`. Semua fatal.
   - `[5/7] Updating package database...` — `pacman -Syu --noconfirm` (wajib, tidak bisa skip — prasyarat install paket apa pun).
   - `[6/7] Installing packages: <user input>...` — `pacman -S --noconfirm <pkgs>`; skip kalau kosong.
   - `[7/7] Cleaning up...` — `pacman -Scc --noconfirm`.
8. Keluar chroot, unmount semua.
9. Sukses → `touch /data/local/chroot/arch/.initialized`. Gagal di step fatal → hapus flag sementara, tampil
   warning, `.initialized` tidak dibuat (bisa retry `setup`).

### 6.3 `pchroot shift` / `pchroot unshift`

Port langsung `do_shift()` dari `sandbox.c`:

- Marker `rootfs/.sandbox-copy` wajib ada (di dalam rootfs, lihat 5.1); kalau tidak ada, tolak dengan pesan pengaman.
- Traverse `nftw` dengan `FTW_PHYS | FTW_MOUNT | FTW_DEPTH`: isi diproses dulu,
  folder induk terakhir — pemilik folder induk jadi penanda status, sehingga proses
  yang terputus bisa dilanjutkan dengan menjalankan perintah yang sama.
- `shift`: pemilik < 100000 ditambah 100000. `unshift`: pemilik di rentang
  [100000, 165536) dikurangi 100000.
- `unshift` mencetak peringatan: bit setuid dan file capability sudah hilang sejak
  shift pertama (perilaku `chown(2)` sejak Linux 2.2.13), pulihkan lewat
  `pacman -S sudo util-linux shadow iputils`.

### 6.4 `pchroot enter`

Inti revisi — sandbox native, port `sandbox.c`. Guard: root, sudah install,
**sudah shift** (pemilik rootfs harus uid 100000; kalau belum, tolak dengan pesan
menyebut `pchroot shift`).

1. Pasang aturan firewall: spawn `ndc firewall set_uid_rule <chain> 100000 allow`
   untuk `dozable`, `powersave`, `restricted`; append output ke log file
   (`/data/local/tmp/pchroot.log`). Skip kalau `--no-firewall`. Mode user:
   pasang aturan yang sama juga untuk uid `100000 + <uid user>` — user 1000 di
   dalam namespace berkuid 101000 di mata Android (map `0 100000 65536`), jadi
   tanpa aturan ini mode user kehilangan internet walau grup `aid_inet`-nya
   benar. Nilai uid user dibaca dari `rootfs/etc/passwd` sebelum sandbox jalan.
2. Baca `/data/local/chroot/arch/.custom_mounts`, mount tiap baris (path salah = `Warning: failed
   to mount <path>`, lanjut — pola mount wajib yang lain).
3. `clone(child_main, ..., flags, args)` dengan `CLONE_NEWNS | CLONE_NEWPID |
   CLONE_NEWUTS | CLONE_NEWIPC | SIGCHLD` (+ `CLONE_NEWNET` kalau `-n`).
4. Di child (masih root asli — urutan ini penting, jangan diubah):
   a. `mount(NULL, "/", MS_REC|MS_PRIVATE)` — semua mount privat.
   b. bind rootfs ke dirinya sendiri, remount `MS_NOSUID|MS_NODEV` (syarat
      pivot_root + menutup celah suid).
   c. mount `/proc` baru (procfs, bukan bind host), `/dev` tmpfs minimal
      (bind `null zero full random urandom tty` dari host, devpts `newinstance`,
      shm tmpfs, symlink `fd/stdin/stdout/stderr`), `/tmp` tmpfs, `/sys` dibiarkan
      kosong (sengaja — tidak mengekspos `/sys` host).
   d. `pivot_root(".", ".")` + `umount2(".", MNT_DETACH)` — root Android hilang
      dari mount table sandbox.
   e. `setgroups(AID_INET)`, `setresgid/setresuid(100000)`, `PR_SET_DUMPABLE`,
      `PR_SET_NO_NEW_PRIVS`, `unshare(CLONE_NEWUSER)`.
   f. Sinyal `ready` lewat pipe, tunggu `go`.
5. Di parent: tulis `uid_map` dan `gid_map` `0 100000 65536` lewat `/proc/<pid>/`;
   masukkan child ke cgroup `pcharch-<pid>` (`+pids` di `subtree_control`, tulis
   `pids.max`, tulis PID ke `cgroup.procs`); kirim `go`. Kalau cgroup gagal: tolak
   masuk dengan pesan jelas, `--pids 0` jalan keluarnya.
6. Di child setelah `go`: tentukan identitas dari `arch/.user` (dioverride
   `--user <nama>`; `--root` memaksa root). Mode user: `setresuid(inner_uid)`
   — supplementary groups yang sudah di-set sebelum userns (termasuk gid real
   3003) tidak dihapus, jadi internet jalan tanpa `su`. Ini menutup kebutuhan
   gap 19 lewat jalur berbeda dari ide gid_map di riset; MEKANISME BARU,
   belum dites di HP. Mode root: persis seperti `sandbox.c`. Lalu drop
   bounding set ke capability bawaan Docker (`a80425fb`), pasang filter
   seccomp BPF denylist (paling akhir sebelum exec),
   `sethostname("pcharch")`, banner
   `[pchroot] user=<nama> uid=<uid> caps=docker seccomp=on` + `pids.max` bila
   aktif, `execve /bin/bash -l` (mode user: HOME dari passwd).
7. Parent: `waitpid`, lalu cleanup cgroup (rmdir dengan retry).

### 6.5 `pchroot uninstall`

Konfirmasi (`--yes` skip) → unmount 5 titik → `rm -rf /data/local/chroot/arch`
(rootfs, downloads, `.initialized`, `.custom_mounts`, `rootfs/.sandbox-copy` ikut terhapus semua).

---

### 6.6 `pchroot run`

Sama persis dengan `enter` (bagian 6.4) sampai langkah 5; bedanya di langkah 6:
`execve` diarahkan ke `<cmd...>` (path absolut di dalam rootfs) sebagai gantinya
`/bin/bash -l`. Non-interaktif: stdin/stdout/stderr child ter-inherit ke terminal
(asli proses induk), jadi output perintah tampil langsung dan tidak "diam-diam";
parent meneruskan exit code perintah ke Termux dan tetap membersihkan cgroup.
Default identitas root (kebutuhan utamanya tugas root ringkas), `--user <nama>`
tersedia. Contoh: `pchroot run -- pacman -Syu`, `pchroot run --user kinkutkut -- make -j4`.

---

## 7. Daftar Syscall Seccomp (port denylist `sandbox.c`)

Ditolak dengan `EPERM`: `kexec_load`, `kexec_file_load`, `reboot`,
`init_module`, `finit_module`, `delete_module`, `create_module`, `query_module`,
`get_kernel_syms`, `swapon`, `swapoff`, `mount`, `umount`, `umount2`,
`pivot_root`, `unshare`, `setns`, `bpf`, `perf_event_open`, `userfaultfd`,
`keyctl`, `add_key`, `request_key`, `open_by_handle_at`, `name_to_handle_at`,
`kcmp`, `acct`, `settimeofday`, `clock_settime`, `clock_adjtime`, `adjtimex`,
`stime`, `syslog`, `lookup_dcookie`, `quotactl`, `nfsservctl`, `sysfs`,
`_sysctl`, `uselib`, `fanotify_init`, `fsopen`, `fsconfig`, `fsmount`,
`fspick`, `move_mount`, `open_tree`, `mount_setattr`, `io_uring_setup`,
`io_uring_enter`, `io_uring_register`, `iopl`, `ioperm`, `modify_ldt`, `vm86`,
`vm86old` — semua dibungkus `#ifdef __NR_*` seperti sumber C, plus pemeriksaan
argumen `clone` menolak `CLONE_NEWUSER`. `clone3` dijawab `ENOSYS`.

`ptrace`/`process_vm_*` sengaja tidak diblokir (`strace`/`gdb` pada proses sendiri
tetap jalan). Denylist disengaja (whitelist terlalu rapuh untuk meja kerja
pacman/git/gcc — alasan riset 4.7).

---

## 8. Yang Sengaja TIDAK Diimplementasi (belum matang)

| Fitur | Status riset | Alasan ditunda |
|---|---|---|
| Fix `gid_map` supaya `su` tidak memutus internet | Dugaan (gap 19), belum diuji | Ide gid_map tidak di-port; kebutuhan yang sama ditangani mekanisme user-drop di 6.4 (baru, perlu uji). `su` tetap dilarang |
| Init mini PID 1 (reap zombie) | Gap 5, belum dikerjakan | Zombie hanya mengganggu sesi sangat panjang; shell masih bisa Ctrl-C |
| TTY/job control penuh (`setsid` + pty) | Gap 6, belum dikerjakan | `tty: ttyname error` tidak berbahaya |
| cgroup `memory`/`cpu` | Mentok struktural (cgroup v1 Android) | Butuh kernel mod `cgroup_no_v1` |
| Alat systemd / `statx` backport | Rencana tahap kernel mod | Butuh kernel mod; dampak kecil |
| systemd sebagai PID 1 | Tidak realistis (kernel 4.9, README systemd ≥5.4/5.10) | Ditinggalkan |
| Auto-ndc via `service.sh` tiap boot | Gap 2, opsi terbuka | `enter` sudah memasang aturan tiap masuk |
| Statistik host disamarkan (bind `/proc` palsu) | Gap 8, prioritas rendah | Kosmetik |

Kalau salah satu matang nanti, itu revisi dokumen tersendiri — bukan tambahan
diam-diam saat port.

---

## 9. Pantangan dan Batasan yang Diwarisi

- **Jangan `su` di dalam sandbox** — internet putus (akar: `initgroups` +
  pemetaan gid, gap 19, belum diperbaiki). Mode root hanya lewat
  `pchroot enter --root` dari sisi Android.
- **Statistik CPU/RAM/load di `htop` tetap milik seluruh HP** — `/proc` tidak
  dipisah per namespace untuk angka sistem.
- **Aturan `ndc` tidak persisten** — sistem Android bisa menimpa chain kapan saja;
  itulah kenapa `enter` memasangnya tiap masuk.
- **Bit setuid/file capability hilang setelah `shift`** — direstorasi lewat
  `pacman -S sudo util-linux shadow iputils` saat mode unshift.
- **User tidak bisa naik root dari dalam sandbox** — `sudo` kehilangan bit setuid
  saat shift; pemakaian root lewat `pchroot enter --root` dari sisi Android.
- **`sandbox` berjalan sebagai root asli sampai fase turun uid** — urutan
  mount → pivot → drop uid → userns tidak boleh diubah; kesalahan urutan adalah
  celah nyata (riset 4.4, 4.5).
- **Batasan fundamental** (satu kernel dengan Android, SELinux permissive,
  filter uid Android, dst.) tetap berlaku penuh — lihat `CHROOT_HANAMA.md`
  bagian 8.

---

## 10. Contoh Output

```
$ pchroot install
ARCH INSTALLATION

Enter download URL:
> http://os.archlinuxarm.org/os/ArchLinuxARM-aarch64-latest.tar.gz

Checking URL...
Estimated size: 178 MB
Checking disk space...
Downloading Arch...
Downloaded: 89 MB / 178 MB (50%)
Extracting...

Install... Done

Next step: pchroot setup
```

```
$ pchroot setup
ARCH SETUP

Mounting filesystems...
Mounting... Done

Add custom mount points? [y/N]: n

Username for sandbox (empty for root-only):
> kinkutkut

Packages to install (space-separated, leave empty to skip):
> sudo nano git htop

[1/7] Creating network groups...
[2/7] Creating user kinkutkut...
[3/7] Disabling CheckSpace, sandbox, and signature checks...
[4/7] Initializing pacman keyring...
[5/7] Updating package database...
[6/7] Installing packages: sudo nano git htop...
[7/7] Cleaning up...

Setup... Done

Run: pchroot shift
```

```
$ pchroot run -- pacman -Syu
[pchroot] firewall rules applied (see /data/local/tmp/pchroot.log)
[pchroot] user=root cmd=/usr/bin/pacman caps=docker seccomp=on
:: Synchronizing package databases...
 core is up to date
...
[pchroot] exit=0
$
```

```
$ pchroot enter
[pchroot] firewall rules applied for uid 100000, 101000 (see /data/local/tmp/pchroot.log)
[pchroot] user=kinkutkut uid=1000 caps=docker seccomp=on
[pchroot] pids.max=1024 (cgroup pcharch-1234)
[kinkutkut@pcharch ~]$
```

Gaya: plain text, tanpa emoji, tanpa AI-slop (CLI-SCHEMA bagian 1b).

---

## 11. Packaging Module KSU

`module.prop`:
```
id=pchroot
name=Arch Chroot Sandbox
version=v1.0
versionCode=1
author=<nama author>
description=Arch Linux ARM chroot with namespace sandbox for KernelSU.
```

`customize.sh`: cek `uname -m` aarch64/arm64 (tolak lainnya), `set_perm_recursive`,
`set_perm $MODPATH/system/bin/pchroot 0 0 0755`, tampilkan usage singkat.

Compile target: `aarch64-unknown-linux-android` (NDK linker, setup toolchain
di luar sesi ini — lihat bagian 12).

Perbedaan cara pakai dari module lama: command berubah dari `installarch` /
`setuparch` / `arch` / `uninstallarch` menjadi `pchroot install|setup|shift|
unshift|enter|run|uninstall`, dan `enter` kini sandbox — perintah `su` di dalam
dilarang (internet putus).

---

## 12. Batasan Sesi Ini

- Environment ini tidak punya Rust toolchain maupun Android NDK — kode yang
  ditulis **tidak divalidasi compile** di sesi ini. Ini dilaporkan sebagai
  temuan, bukan diasumsikan jalan; validasi compile jadi bagian dari konfirmasi
  tiap step oleh user di environment-nya.
- Belum ada baris kode ditulis; eksekusi menyusul per-step (Part 2: incremental,
  konfirmasi user antar step).
- Cross-compile module KSU (bagian 11) sepenuhnya di tangan user.

---

## 13. Urutan Eksekusi (4 step)

1. **Fondasi** — `Cargo.toml` + `main.rs` + `cli.rs` + `error.rs` + `arch.rs`
   (konstanta + URL). Dispatch clap jalan, 7 subcommand terdaftar. Hasil
   compile: binary bisa dipanggil, tiap subcommand menjawab guard root atau
   pesan "belum diimplementasi".
2. **Alur klasik host** — `commands/install.rs` + `commands/setup.rs` +
   `shift.rs`. Tiga operasi tanpa namespace: download/extract/validasi,
   mount klasik + 7 langkah setup, port `do_shift`/`do_unshift`. Bisa diuji
   penuh di HP tanpa sandbox.
3. **Inti sandbox** — `sandbox/` (`cgroup.rs`, `seccomp.rs`, `child.rs`,
   `parent.rs`) + `commands/enter.rs` + `commands/run.rs`. Port `sandbox.c` + aturan ndc
   terintegrasi. Step terbesar, paling perlu ketelitian urutan syscall.
   Filter seccomp `__NR_*` di-gate per arsitektur (`__aarch64__`/`__x86_64__`)
   agar bisa diuji di lingkungan uji x86_64 juga.
4. **Penutup** — `commands/uninstall.rs` + `tests/integration_test.rs`
   minimal + packaging module KSU (`module.prop`, `customize.sh`).

Tiap step: kirim zip berisi hanya file yang berubah, tunggu konfirmasi user
berhasil compile/jalan sebelum lanjut (Part 2 workflow).

---

## 14. Ringkasan Perbedaan dari Rancangan Lama

| Aspek | Rancangan lama (dchroot) | Revisi (pchroot) |
|---|---|---|
| Distro | 4 (alpine/ubuntu/kali/arch) | Arch saja |
| Argumen distro | `dchroot install arch` | `pchroot install` |
| Mekanisme enter | spawn `chroot` eksternal | sandbox native (port `sandbox.c`) |
| Trait DistroSetup | ada | dihapus (satu distro) |
| Mount sdcard/system | wajib | dihapus (celah, temuan riset) |
| Firewall ndc | tidak ada (wrapper terpisah `sb`) | terintegrasi di `enter` + `--no-firewall` |
| shift/unshift | tidak ada | subcommand eksplisit |
| Seccomp/caps/cgroup | tidak ada | denylist BPF + set Docker + pids |
| Subcommand | install/setup/enter/uninstall | + shift + unshift + run |
| user namespace | tidak ada | inti: `0 -> 100000`, range 65536 |
