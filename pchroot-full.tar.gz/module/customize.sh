#!/system/bin/sh

SKIPUNZIP=0

ui_print ""

ARCH=$(uname -m)
if [ "$ARCH" != "aarch64" ] && [ "$ARCH" != "arm64" ]; then
    ui_print "Error: ARM64 only"
    ui_print "Your device: $ARCH"
    exit 1
fi

ui_print "Setting permissions..."
set_perm_recursive $MODPATH 0 0 0755 0644
set_perm $MODPATH/system/bin/pchroot 0 0 0755

ui_print ""
ui_print "Installation complete"
ui_print ""
ui_print "Usage:"
ui_print "  su"
ui_print "  pchroot install"
ui_print "  pchroot setup"
ui_print "  pchroot shift"
ui_print "  pchroot enter"
ui_print ""
