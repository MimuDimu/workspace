use std::path::Path;

// Constants for the pchroot workspace. All host-side state lives under
// /data/local/chroot/arch except the firewall log (see rancangan bagian 5.1).

pub const BASE: u32 = 100000;
pub const RANGE: u32 = 65536;
pub const AID_INET: u32 = 3003;
pub const AID_NET_RAW: u32 = 3004;
pub const AID_GRAPHICS: u32 = 1003;
pub const DEFAULT_PIDS: u32 = 1024;

pub const BASE_DIR: &str = "/data/local/chroot/arch";
pub const ROOTFS_DIR: &str = "/data/local/chroot/arch/rootfs";
pub const DOWNLOADS_DIR: &str = "/data/local/chroot/arch/downloads";
pub const INITIALIZED_FLAG: &str = "/data/local/chroot/arch/.initialized";
pub const CUSTOM_MOUNTS_FILE: &str = "/data/local/chroot/arch/.custom_mounts";
pub const USER_FILE: &str = "/data/local/chroot/arch/.user";
pub const LOG_FILE: &str = "/data/local/tmp/pchroot.log";

// Inside the rootfs on purpose: the marker must travel with cp -a copies and
// marks the directory that is meant to be shifted (see rancangan 5.1).
pub const SHIFT_MARKER: &str = "/data/local/chroot/arch/rootfs/.sandbox-copy";

pub const HOSTNAME: &str = "pcharch";
pub const DEFAULT_URL: &str = "http://os.archlinuxarm.org/os/ArchLinuxARM-aarch64-latest.tar.gz";
pub const RESOLV_CONF_CONTENT: &str =
    "nameserver 8.8.8.8\nnameserver 8.8.4.4\nnameserver 1.1.1.1\n";

pub fn rootfs() -> &'static Path {
    Path::new(ROOTFS_DIR)
}

pub fn base_dir() -> &'static Path {
    Path::new(BASE_DIR)
}
