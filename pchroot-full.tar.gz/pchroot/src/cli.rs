use clap::{Args, Parser, Subcommand};

use crate::arch::DEFAULT_PIDS;

#[derive(Parser)]
#[command(
    name = "pchroot",
    version,
    about = "Arch Linux ARM chroot sandbox for KernelSU",
    subcommand_required = true,
    arg_required_else_help = true
)]
pub struct Cli {
    #[command(subcommand)]
    pub command: Command,
}

#[derive(Subcommand)]
pub enum Command {
    /// Download and extract the Arch Linux ARM rootfs
    Install(InstallArgs),
    /// One-time rootfs configuration (groups, pacman fixes, user)
    Setup(SetupArgs),
    /// Shift rootfs ownership +100000 (required before enter)
    Shift,
    /// Undo the ownership shift
    Unshift,
    /// Enter the sandbox with an interactive shell
    Enter(EnterArgs),
    /// Run one command inside the sandbox (default: as root)
    Run(RunArgs),
    /// Remove rootfs, downloads, and all pchroot state
    Uninstall(UninstallArgs),
}

#[derive(Args)]
pub struct InstallArgs {
    /// Rootfs tarball URL
    #[arg(long, value_name = "URL")]
    pub url: Option<String>,
    /// Skip confirmation prompts
    #[arg(long, short = 'y')]
    pub yes: bool,
}

#[derive(Args)]
pub struct SetupArgs {
    /// Skip confirmation prompts
    #[arg(long, short = 'y')]
    pub yes: bool,
}

// Shared sandbox flags for enter and run. One struct, flattened into both, so
// the flag set cannot drift between the two commands.
#[derive(Args)]
pub struct SandboxArgs {
    /// Empty network namespace (no internet at all)
    #[arg(short = 'n')]
    pub net: bool,
    /// Max processes+threads via cgroup (0 disables the limit)
    #[arg(long, default_value_t = DEFAULT_PIDS)]
    pub pids: u32,
    /// Do not install the seccomp filter
    #[arg(long = "no-seccomp")]
    pub no_seccomp: bool,
    /// Keep all capabilities instead of the Docker default set
    #[arg(long = "keep-caps")]
    pub keep_caps: bool,
    /// Skip the ndc firewall rules
    #[arg(long = "no-firewall")]
    pub no_firewall: bool,
    /// Enter as root (default: user from arch/.user, or root if none)
    #[arg(long, conflicts_with = "user")]
    pub root: bool,
    /// Enter as this user instead of the configured default
    #[arg(long, value_name = "NAME")]
    pub user: Option<String>,
}

#[derive(Args)]
pub struct EnterArgs {
    #[command(flatten)]
    pub sandbox: SandboxArgs,
}

#[derive(Args)]
pub struct RunArgs {
    #[command(flatten)]
    pub sandbox: SandboxArgs,
    /// Command to run, absolute path inside the rootfs (use -- before it)
    #[arg(required = true, last = true, value_name = "CMD")]
    pub command: Vec<String>,
}

#[derive(Args)]
pub struct UninstallArgs {
    /// Skip the confirmation prompt
    #[arg(long, short = 'y')]
    pub yes: bool,
}
