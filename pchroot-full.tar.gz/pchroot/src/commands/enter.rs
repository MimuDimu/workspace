use crate::arch;
use crate::cli::EnterArgs;
use crate::commands::check_sandbox_ready;
use crate::error::Result;
use crate::sandbox::{self, SandboxConfig};

pub fn run(args: &EnterArgs) -> Result<i32> {
    check_sandbox_ready()?;

    // Default identity: the user from arch/.user, root when none is set.
    let id = crate::commands::resolve_identity(&args.sandbox, true)?;
    apply_rules(&id)?;
    let mounts = sandbox::read_custom_mounts();

    sandbox::run(SandboxConfig {
        net: args.sandbox.net,
        pids: args.sandbox.pids,
        seccomp: !args.sandbox.no_seccomp,
        keep_caps: args.sandbox.keep_caps,
        custom_mounts: mounts,
        identity: id,
        command: None,
    })
}

pub(crate) fn apply_rules(id: &sandbox::Identity) -> Result<()> {
    let mut uids = vec![arch::BASE];
    if id.uid != 0 {
        uids.push(arch::BASE + id.uid); // inner 1000 is kuid 101000 to Android
    }
    sandbox::apply_firewall(&uids)
}
