use std::fs::{self, File};
use std::io::{self, Read, Write};
use std::path::Path;
use std::process::Command;

use crate::arch;
use crate::cli::InstallArgs;
use crate::error::{AppError, Result};
use crate::{heading, prompt};

const TARBALL_NAME: &str = "archlinuxarm-rootfs.tar.gz";
const MB: u64 = 1024 * 1024;

pub fn run(args: &InstallArgs) -> Result<i32> {
    println!("{}", heading("ARCH", "INSTALLATION"));
    println!();

    if arch::rootfs().join("usr/bin/bash").exists() {
        return Err(AppError::InvalidArgs(
            "rootfs already installed; run pchroot uninstall first".into(),
        ));
    }

    let url = resolve_url(args)?;

    println!("Checking URL...");
    let total = check_url(&url)?;
    match total {
        Some(n) => println!("Estimated size: {} MB", n / MB),
        None => println!("Estimated size: unknown"),
    }

    println!("Checking disk space...");
    let avail = free_bytes_on("/data")?;
    if let Some(n) = total {
        if avail < n.saturating_mul(2) {
            return Err(AppError::InvalidArgs(format!(
                "not enough space on /data: need ~{} MB, have {} MB",
                n * 2 / MB,
                avail / MB
            )));
        }
    }

    fs::create_dir_all(arch::DOWNLOADS_DIR)
        .map_err(|e| AppError::Io { what: "mkdir downloads".into(), source: e })?;
    fs::create_dir_all(arch::ROOTFS_DIR)
        .map_err(|e| AppError::Io { what: "mkdir rootfs".into(), source: e })?;
    let tarball = Path::new(arch::DOWNLOADS_DIR).join(TARBALL_NAME);

    println!("Downloading Arch...");
    download(&url, &tarball, total)?;

    println!("Extracting...");
    let st = Command::new("tar")
        .arg("-xzf")
        .arg(&tarball)
        .arg("-C")
        .arg(arch::ROOTFS_DIR)
        .status()
        .map_err(|e| AppError::Io { what: "spawn tar".into(), source: e })?;
    if !st.success() {
        return Err(AppError::Cmd("tar extract failed".into()));
    }

    if !arch::rootfs().join("usr/bin/bash").exists() {
        return Err(AppError::Cmd(
            "extracted rootfs is missing /usr/bin/bash; wrong tarball?".into(),
        ));
    }

    // Stock Arch resolv.conf is a symlink to systemd-resolved, which does not
    // exist here; remove before writing or the write fails with ENOENT.
    let _ = fs::remove_file(arch::rootfs().join("etc/resolv.conf"));
    fs::write(arch::rootfs().join("etc/resolv.conf"), arch::RESOLV_CONF_CONTENT)
        .map_err(|e| AppError::Io { what: "write resolv.conf".into(), source: e })?;

    println!();
    println!("Install... Done");
    println!();
    println!("Next step: pchroot setup");
    Ok(0)
}

// Flag wins; without it, prompt unless --yes, which takes the default URL.
fn resolve_url(args: &InstallArgs) -> Result<String> {
    if let Some(u) = &args.url {
        return Ok(u.clone());
    }
    if args.yes {
        return Ok(arch::DEFAULT_URL.to_string());
    }
    let u = prompt("Enter download URL:\n> ").map_err(|e| AppError::Io {
        what: "read prompt".into(),
        source: e,
    })?;
    Ok(if u.is_empty() { arch::DEFAULT_URL.to_string() } else { u })
}

// Probe the URL with a 1-byte range request and read the total from Content-Range.
fn check_url(url: &str) -> Result<Option<u64>> {
    let resp = ureq::get(url)
        .set("Range", "bytes=0-0")
        .call()
        .map_err(|e| AppError::Http(format!("cannot reach {url}: {e}")))?;
    Ok(resp.header("Content-Range").and_then(parse_total))
}

// "bytes 0-0/17825792" -> 17825792
fn parse_total(header: &str) -> Option<u64> {
    header.rsplit('/').next()?.parse().ok()
}

fn download(url: &str, dest: &Path, total: Option<u64>) -> Result<()> {
    let resp = ureq::get(url)
        .call()
        .map_err(|e| AppError::Http(format!("download failed: {e}")))?;
    let mut reader = resp.into_reader();
    let mut file =
        File::create(dest).map_err(|e| AppError::Io { what: "create tarball".into(), source: e })?;

    let mut buf = [0u8; 64 * 1024];
    let mut got: u64 = 0;
    let mut next_mark: u64 = 4 * MB;
    loop {
        let n = reader
            .read(&mut buf)
            .map_err(|e| AppError::Io { what: "read response".into(), source: e })?;
        if n == 0 {
            break;
        }
        file.write_all(&buf[..n])
            .map_err(|e| AppError::Io { what: "write tarball".into(), source: e })?;
        got += n as u64;
        if got >= next_mark {
            match total {
                Some(t) => print!(
                    "\rDownloaded: {} MB / {} MB ({}%)",
                    got / MB,
                    t / MB,
                    got * 100 / t
                ),
                None => print!("\rDownloaded: {} MB", got / MB),
            }
            let _ = io::stdout().flush();
            next_mark += 4 * MB;
        }
    }
    println!();
    Ok(())
}

fn free_bytes_on(path: &str) -> Result<u64> {
    use std::ffi::CString;
    let c_path = CString::new(path).expect("static path has no NUL");
    let mut st: libc::statfs = unsafe { std::mem::zeroed() };
    let rc = unsafe { libc::statfs(c_path.as_ptr(), &mut st) };
    if rc != 0 {
        return Err(AppError::Io {
            what: format!("statfs {path}"),
            source: io::Error::last_os_error(),
        });
    }
    Ok(st.f_bavail as u64 * st.f_bsize as u64)
}
