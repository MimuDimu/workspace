pub mod enter;
pub mod install;
pub mod run;
pub mod setup;

use std::os::unix::fs::MetadataExt;
use std::path::Path;

use crate::arch;
use crate::cli::SandboxArgs;
use crate::error::{AppError, Result};
use crate::sandbox::Identity;

// Shared guards for enter/run: rootfs installed and already shifted.
// Reverse order of the classic mounts, plus custom mounts. Shared by setup
// and uninstall.
pub fn unmount_all() {
    let custom = std::fs::read_to_string(arch::CUSTOM_MOUNTS_FILE).unwrap_or_default();
    for line in custom.lines() {
        if let Some((_, c)) = line.split_once('|') {
            umount_lazy(&arch::rootfs().join(c));
        }
    }
    for m in ["proc", "sys", "dev/pts", "dev/shm", "dev"] {
        umount_lazy(&arch::rootfs().join(m));
    }
}

pub fn prompt_yn(text: &str) -> Result<bool> {
    let a = crate::prompt(&format!("{text}: ")).map_err(|e| AppError::Io { what: "read prompt".into(), source: e })?;
    Ok(matches!(a.as_str(), "y" | "Y" | "yes" | "YES"))
}

pub fn check_sandbox_ready() -> Result<()> {
    if !arch::rootfs().join("usr/bin/bash").exists() {
        return Err(AppError::InvalidArgs("rootfs not installed; run pchroot install first".into()));
    }
    let owner = std::fs::metadata(arch::rootfs())
        .map_err(|e| AppError::Io { what: "stat rootfs".into(), source: e })?
        .uid();
    if owner != arch::BASE {
        return Err(AppError::InvalidArgs(format!(
            "rootfs not shifted (owner {owner}); run pchroot shift first"
        )));
    }
    Ok(())
}

// Resolve who to become inside the sandbox.
// prefer_file=true (enter): --user wins, else arch/.user, else root.
// prefer_file=false (run):  --user wins, else root.
pub fn resolve_identity(args: &SandboxArgs, prefer_file: bool) -> Result<Identity> {
    let name = if let Some(u) = &args.user {
        Some(u.clone())
    } else if !args.root && prefer_file {
        std::fs::read_to_string(arch::USER_FILE)
            .ok()
            .map(|s| s.trim().to_string())
            .filter(|s| !s.is_empty())
    } else {
        None
    };
    let Some(name) = name else {
        return Ok(Identity::root());
    };
    let passwd = std::fs::read_to_string(arch::rootfs().join("etc/passwd"))
        .map_err(|e| AppError::Io { what: "read rootfs/etc/passwd".into(), source: e })?;
    for line in passwd.lines() {
        let f: Vec<&str> = line.split(':').collect();
        if f.len() >= 6 && f[0] == name {
            let uid: u32 = f[2].parse().map_err(|_| AppError::InvalidArgs(format!("bad uid for {name}")))?;
            let gid: u32 = f[3].parse().map_err(|_| AppError::InvalidArgs(format!("bad gid for {name}")))?;
            return Ok(Identity { name, uid, gid, home: f[5].to_string() });
        }
    }
    Err(AppError::InvalidArgs(format!("user {name} not found in rootfs; run pchroot setup first")))
}

use std::process::Command;

// Classic bind mounts for the setup-time chroot. The sandbox does its own
// mounts via syscall and does not use these.

pub fn mount_bind(source: &str, target: &Path) -> Result<()> {
    run_mount(
        Command::new("mount").arg("-o").arg("bind").arg(source).arg(target),
        &format!("mount {source} -> {}", target.display()),
    )
}

pub fn mount_devpts(target: &Path) -> Result<()> {
    run_mount(
        Command::new("mount").args(["-t", "devpts", "devpts"]).arg(target),
        &format!("mount devpts -> {}", target.display()),
    )
}

pub fn mount_proc(target: &Path) -> Result<()> {
    run_mount(
        Command::new("mount").args(["-t", "proc", "proc"]).arg(target),
        &format!("mount proc -> {}", target.display()),
    )
}

pub fn umount_lazy(target: &Path) {
    let _ = Command::new("umount").arg("-l").arg(target).status();
}

pub fn ensure_dir(path: &Path) -> Result<()> {
    std::fs::create_dir_all(path).map_err(|e| AppError::Io { what: format!("mkdir {}", path.display()), source: e })
}

fn run_mount(cmd: &mut Command, what: &str) -> Result<()> {
    let st = cmd
        .status()
        .map_err(|e| AppError::Io { what: "spawn mount".into(), source: e })?;
    if st.success() {
        Ok(())
    } else {
        Err(AppError::Cmd(format!("{what} failed")))
    }
}
