use crate::cli::RunArgs;
use crate::commands::check_sandbox_ready;
use crate::error::{AppError, Result};
use crate::sandbox::{self, SandboxConfig};

pub fn run(args: &RunArgs) -> Result<i32> {
    check_sandbox_ready()?;

    if !args.command[0].starts_with('/') {
        return Err(AppError::InvalidArgs(
            "command must be an absolute path inside the rootfs".into(),
        ));
    }

    // Default identity for run is root; --user selects a user explicitly.
    let id = crate::commands::resolve_identity(&args.sandbox, false)?;
    crate::commands::enter::apply_rules(&id)?;

    sandbox::run(SandboxConfig {
        net: args.sandbox.net,
        pids: args.sandbox.pids,
        seccomp: !args.sandbox.no_seccomp,
        keep_caps: args.sandbox.keep_caps,
        custom_mounts: sandbox::read_custom_mounts(),
        identity: id,
        command: Some(args.command.clone()),
    })
}
