use std::fs;
use std::path::Path;
use std::process::Command;

use crate::arch;
use crate::cli::SetupArgs;
use crate::commands::{ask_yn, ensure_dir, mount_bind, mount_devpts, mount_proc, unmount_all, umount_lazy};
use crate::error::{AppError, Result};
use crate::{heading, prompt};

// All setup steps are fatal: any failure aborts, unmounts, and leaves
// .initialized unwritten so setup can be retried (rancangan 6.2).
const GROUPS: &str = "groupadd -f aid_inet && groupadd -f aid_net_raw && groupadd -f aid_graphics && usermod -aG aid_inet root";
const PACMAN_CONF_FIXES: &str = "sed -i 's/^CheckSpace/#CheckSpace/' /etc/pacman.conf && { grep -q '^DisableSandbox' /etc/pacman.conf || sed -i '/^\\[options\\]/a DisableSandbox' /etc/pacman.conf; } && sed -i 's/^SigLevel.*/SigLevel = Never/' /etc/pacman.conf";
const KEYRING: &str = "rm -rf /etc/pacman.d/gnupg && pacman-key --init && pacman-key --populate archlinuxarm && pacman-key --refresh-keys";
const UPDATE_DB: &str = "pacman -Syu --noconfirm";
const CLEANUP: &str = "pacman -Scc --noconfirm";

pub fn run(args: &SetupArgs) -> Result<i32> {
    println!("{}", heading("ARCH", "SETUP"));
    println!();

    if !arch::rootfs().join("usr/bin/bash").exists() {
        return Err(AppError::InvalidArgs(
            "rootfs not installed; run pchroot install first".into(),
        ));
    }
    if Path::new(arch::INITIALIZED_FLAG).exists() {
        return Err(AppError::InvalidArgs("already set up".into()));
    }

    println!("Mounting filesystems...");
    // Clean leftovers from a killed session, then mount the 5 classic points.
    for m in ["dev/pts", "dev/shm", "dev", "sys", "proc"] {
        umount_lazy(&arch::rootfs().join(m));
    }
    mount_bind("/dev", &arch::rootfs().join("dev"))?;
    ensure_dir(&arch::rootfs().join("dev/shm"))?;
    let _ = mount_bind("/dev/shm", &arch::rootfs().join("dev/shm"));
    ensure_dir(&arch::rootfs().join("dev/pts"))?;
    let _ = mount_devpts(&arch::rootfs().join("dev/pts"));
    ensure_dir(&arch::rootfs().join("sys"))?;
    mount_bind("/sys", &arch::rootfs().join("sys"))?;
    ensure_dir(&arch::rootfs().join("proc"))?;
    mount_proc(&arch::rootfs().join("proc"))?;
    println!("Mounting... Done");
    println!();

    let mut custom: Vec<(String, String)> = Vec::new();
    if !args.yes && ask_yn("Add custom mount points? [y/N]")? {
        loop {
            let host = read_prompt("Host path:\n> ")?;
            if host.is_empty() {
                break;
            }
            let chroot_path = read_prompt("Chroot path (relative to rootfs):\n> ")?;
            let target = arch::rootfs().join(&chroot_path);
            if let Err(e) = ensure_dir(&target).and_then(|_| mount_bind(&host, &target)) {
                eprintln!("Warning: failed to mount {host}: {e}");
            } else {
                custom.push((host, chroot_path));
            }
            if !ask_yn("Add another? [y/N]")? {
                break;
            }
        }
    }
    if !custom.is_empty() {
        let lines: Vec<String> = custom.iter().map(|(h, c)| format!("{h}|{c}")).collect();
        fs::write(arch::CUSTOM_MOUNTS_FILE, lines.join("\n") + "\n")
            .map_err(|e| AppError::Io { what: "write .custom_mounts".into(), source: e })?;
    }

    // With --yes the text prompts are skipped too; that means root-only mode
    // and no extra packages. Stated here so --yes is never a silent surprise.
    if args.yes {
        println!("(defaults: no custom mounts, root-only mode, no extra packages)");
    }
    let username = if args.yes {
        String::new()
    } else {
        read_prompt("Username for sandbox (empty for root-only):\n> ")?
    };
    if !username.is_empty() && !valid_username(&username) {
        unmount_all();
        return Err(AppError::InvalidArgs(format!("invalid username: {username}")));
    }
    let packages = if args.yes {
        String::new()
    } else {
        read_prompt("Packages to install (space-separated, empty to skip):\n> ")?
    };

    let mut steps: Vec<(String, String)> = Vec::new();
    steps.push(("Creating network groups...".into(), GROUPS.into()));
    if !username.is_empty() {
        steps.push((
            format!("Creating user {username}..."),
            format!("useradd -m -G wheel -s /bin/bash {username}"),
        ));
    }
    steps.push((
        "Disabling CheckSpace, sandbox, and signature checks...".into(),
        PACMAN_CONF_FIXES.into(),
    ));
    steps.push(("Initializing pacman keyring...".into(), KEYRING.into()));
    steps.push(("Updating package database...".into(), UPDATE_DB.into()));
    if !packages.is_empty() {
        steps.push((
            format!("Installing packages: {packages}..."),
            format!("pacman -S --noconfirm {packages}"),
        ));
    }
    steps.push(("Cleaning up...".into(), CLEANUP.into()));

    let total = steps.len();
    for (i, (label, cmd)) in steps.iter().enumerate() {
        println!("[{}/{}] {}", i + 1, total, label);
        if !chroot_bash(cmd)? {
            eprintln!("error: setup step {} failed: {}", i + 1, label);
            unmount_all();
            return Err(AppError::Cmd(format!("setup step {} failed", i + 1)));
        }
    }

    if !username.is_empty() {
        fs::write(arch::USER_FILE, format!("{username}\n"))
            .map_err(|e| AppError::Io { what: "write .user".into(), source: e })?;
    }

    unmount_all();
    fs::write(arch::INITIALIZED_FLAG, "").map_err(|e| AppError::Io {
        what: "write .initialized".into(),
        source: e,
    })?;

    println!();
    println!("Setup... Done");
    println!();
    println!("Run: pchroot shift");
    Ok(0)
}

fn chroot_bash(cmd: &str) -> Result<bool> {
    let st = Command::new("chroot")
        .arg(arch::ROOTFS_DIR)
        .arg("/bin/bash")
        .arg("-c")
        .arg(cmd)
        .status()
        .map_err(|e| AppError::Io { what: "spawn chroot".into(), source: e })?;
    Ok(st.success())
}

fn read_prompt(text: &str) -> Result<String> {
    prompt(text).map_err(|e| AppError::Io { what: "read prompt".into(), source: e })
}

fn valid_username(s: &str) -> bool {
    let mut chars = s.chars();
    match chars.next() {
        Some(c) if c.is_ascii_lowercase() || c == '_' => {}
        _ => return false,
    }
    s.chars()
        .all(|c| c.is_ascii_lowercase() || c.is_ascii_digit() || c == '_' || c == '-')
}
