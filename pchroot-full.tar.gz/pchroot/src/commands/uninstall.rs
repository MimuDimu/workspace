use std::path::Path;

use crate::arch;
use crate::cli::UninstallArgs;
use crate::commands::{prompt_yn, unmount_all};
use crate::error::{AppError, Result};
use crate::heading;

pub fn run(args: &UninstallArgs) -> Result<i32> {
    println!("{}", heading("ARCH", "UNINSTALL"));
    println!();

    if !Path::new(arch::BASE_DIR).exists() {
        return Err(AppError::InvalidArgs("nothing to remove; rootfs not installed".into()));
    }

    if !args.yes && !prompt_yn("This will remove the Arch rootfs, downloads, and setup flag. Continue? [y/N]")? {
        println!("Aborted.");
        return Ok(0);
    }

    println!("Unmounting filesystems...");
    unmount_all();

    println!("Removing files...");
    // Everything lives under /data/local/chroot/arch: rootfs, downloads,
    // .initialized, .custom_mounts, .user, and the rootfs/.sandbox-copy marker.
    std::fs::remove_dir_all(arch::BASE_DIR)
        .map_err(|e| AppError::Io { what: format!("remove {}", arch::BASE_DIR), source: e })?;

    println!();
    println!("Uninstall... Done");
    Ok(0)
}
