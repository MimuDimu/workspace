use std::fmt;

// Single error type for the whole app. One-line messages to stderr, no hints.
#[derive(Debug)]
pub enum AppError {
    NotRoot,
    InvalidArgs(String),
    Http(String),
    Cmd(String),
    Io { what: String, source: std::io::Error },
}

pub type Result<T> = std::result::Result<T, AppError>;

impl fmt::Display for AppError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            AppError::NotRoot => write!(f, "error: must be run as root"),
            AppError::InvalidArgs(msg) => write!(f, "error: {msg}"),
            AppError::Http(msg) => write!(f, "error: {msg}"),
            AppError::Cmd(msg) => write!(f, "error: {msg}"),
            AppError::Io { what, source } => write!(f, "error: {what}: {source}"),
        }
    }
}

impl std::error::Error for AppError {
    fn source(&self) -> Option<&(dyn std::error::Error + 'static)> {
        match self {
            AppError::Io { source, .. } => Some(source),
            _ => None,
        }
    }
}
