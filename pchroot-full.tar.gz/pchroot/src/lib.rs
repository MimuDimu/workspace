pub mod arch;
pub mod cli;
pub mod commands;
pub mod error;
pub mod sandbox;
pub mod shift;

use cli::Command;
use error::{AppError, Result};

// Central dispatch for all subcommands. Kept thin; real logic lives in commands/
// and shift/ (step 2), sandbox/ + commands for enter/run (step 3).
pub fn run(cli: cli::Cli) -> Result<i32> {
    // Every subcommand touches paths and mounts owned by root.
    if unsafe { libc::geteuid() } != 0 {
        return Err(AppError::NotRoot);
    }
    match cli.command {
        Command::Install(a) => commands::install::run(&a),
        Command::Setup(a) => commands::setup::run(&a),
        Command::Shift => shift::run(true),
        Command::Unshift => shift::run(false),
        Command::Enter(a) => commands::enter::run(&a),
        Command::Run(a) => commands::run::run(&a),
        Command::Uninstall(a) => commands::uninstall::run(&a),
    }
}

// Single place that builds "ARCH INSTALLATION"-style headings (rancangan bagian 5).
pub fn heading(part1: &str, part2: &str) -> String {
    format!("{part1} {part2}")
}

// One interactive prompt, pattern "Label:\n> ". Empty input is a valid answer.
pub fn prompt(text: &str) -> std::io::Result<String> {
    use std::io::Write;
    print!("{text}");
    std::io::stdout().flush()?;
    let mut s = String::new();
    std::io::stdin().read_line(&mut s)?;
    Ok(s.trim().to_string())
}
