use clap::Parser;

use pchroot::cli::Cli;

fn main() {
    let cli = Cli::parse();
    match pchroot::run(cli) {
        Ok(code) => std::process::exit(code),
        Err(e) => {
            eprintln!("{e}");
            std::process::exit(1);
        }
    }
}
