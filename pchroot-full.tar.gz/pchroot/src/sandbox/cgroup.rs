use crate::error::{AppError, Result};

use super::CGROUP_ROOT;

// Join the sandbox process to a pids-only cgroup group; removed by cleanup()
// after the sandbox exits.
pub fn join(pid: i32, max_pids: u32, dir_out: &mut String) -> Result<()> {
    // Idempotent; may fail when the subtree already has it.
    let _ = put(&format!("{CGROUP_ROOT}/cgroup.subtree_control"), "+pids");
    let dir = format!("{CGROUP_ROOT}/pcharch-{pid}");
    std::fs::create_dir(&dir).map_err(|e| AppError::Io { what: format!("mkdir {dir}"), source: e })?;
    put(&format!("{dir}/pids.max"), &max_pids.to_string())?;
    put(&format!("{dir}/cgroup.procs"), &pid.to_string())?;
    *dir_out = dir;
    Ok(())
}

pub fn cleanup(dir: &str) {
    for _ in 0..30 {
        if std::fs::remove_dir(dir).is_ok() {
            return;
        }
        unsafe { libc::usleep(100_000) };
    }
    eprintln!("pchroot: cgroup cleanup failed: {dir}");
}

fn put(path: &str, value: &str) -> Result<()> {
    std::fs::write(path, value).map_err(|e| AppError::Io { what: format!("write {path}"), source: e })
}
