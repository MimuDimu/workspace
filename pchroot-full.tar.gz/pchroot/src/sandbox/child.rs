use std::ffi::{c_char, c_void, CString};
use std::os::unix::ffi::OsStrExt;
use std::path::Path;

use libc::c_int;

use crate::arch;
use crate::error::{AppError, Result};

use super::seccomp;
use super::SandboxConfig;

pub struct ChildStart {
    pub cfg: SandboxConfig,
    pub ready_w: i32,
    pub go_r: i32,
}

pub extern "C" fn trampoline(arg: *mut c_void) -> c_int {
    // Runs as PID 1 in the new namespaces. Never returns to Rust normally:
    // either execve succeeds or the process exits with an error message.
    let start = unsafe { &*(arg as *const ChildStart) };
    match run(&start.cfg, start.ready_w, start.go_r) {
        Ok(code) => code,
        Err(e) => {
            eprintln!("{e}");
            1
        }
    }
}

fn run(cfg: &SandboxConfig, ready_w: i32, go_r: i32) -> Result<i32> {
    setup_mounts(cfg)?;
    pivot_into()?;

    // Groups must be set while the process is still root in the initial user
    // namespace: AID_INET (real gid 3003) is what Android's filter checks.
    let groups: [libc::gid_t; 1] = [arch::AID_INET];
    let rc = if cfg.net {
        unsafe { libc::setgroups(0, std::ptr::null()) }
    } else {
        unsafe { libc::setgroups(1, groups.as_ptr()) }
    };
    if rc != 0 {
        return Err(io_err("setgroups"));
    }

    // Drop to kuid/kgid BASE before unshare(CLONE_NEWUSER) so the map
    // "0 100000 65536" actually translates this process (CHROOT_HANAMA 4.4).
    if unsafe { libc::setresgid(arch::BASE, arch::BASE, arch::BASE) } != 0 {
        return Err(io_err("setresgid"));
    }
    if unsafe { libc::setresuid(arch::BASE, arch::BASE, arch::BASE) } != 0 {
        return Err(io_err("setresuid"));
    }
    if unsafe { libc::prctl(libc::PR_SET_DUMPABLE, 1, 0, 0, 0) } != 0 {
        return Err(io_err("PR_SET_DUMPABLE"));
    }
    if unsafe { libc::prctl(libc::PR_SET_NO_NEW_PRIVS, 1, 0, 0, 0) } != 0 {
        return Err(io_err("PR_SET_NO_NEW_PRIVS"));
    }

    if unsafe { libc::unshare(libc::CLONE_NEWUSER) } != 0 {
        return Err(io_err("unshare(CLONE_NEWUSER)"));
    }

    signal_ready(ready_w)?;
    if !wait_go(go_r) {
        return Ok(1); // parent died or map write failed; message already printed
    }

    banner(cfg);

    // User mode: drop from inner root to the user. setresuid does not touch
    // supplementary groups, so AID_INET survives and the internet keeps
    // working without su (CHROOT_HANAMA gap 19 solved by another route).
    if cfg.identity.uid != 0 {
        if unsafe { libc::setresgid(cfg.identity.gid, cfg.identity.gid, cfg.identity.gid) } != 0 {
            return Err(io_err("setresgid(user)"));
        }
        if unsafe { libc::setresuid(cfg.identity.uid, cfg.identity.uid, cfg.identity.uid) } != 0 {
            return Err(io_err("setresuid(user)"));
        }
    }

    if !cfg.keep_caps {
        drop_caps()?;
    }
    if cfg.seccomp {
        seccomp::install()?; // last: everything else must already be done
    }

    exec(cfg)
}

// Mount phase, all done as real root before entering the user namespace.
fn setup_mounts(cfg: &SandboxConfig) -> Result<()> {
    mount(None, &c("/")?, None, libc::MS_REC | libc::MS_PRIVATE, None)
        .map_err(|_| io_err("make-rprivate /"))?;

    // bind rootfs to itself so it becomes its own mount point, then lock it
    let root = c(arch::ROOTFS_DIR)?;
    mount(Some(&root), &root, None, libc::MS_BIND | libc::MS_REC, None)
        .map_err(|_| io_err("bind rootfs"))?;
    mount(None, &root, None, libc::MS_REMOUNT | libc::MS_BIND | libc::MS_NOSUID | libc::MS_NODEV, None)
        .map_err(|_| io_err("remount rootfs nosuid,nodev"))?;
    if unsafe { libc::chdir(root.as_ptr()) } != 0 {
        return Err(io_err("chdir rootfs"));
    }

    mkdir("proc")?;
    mount(Some(&c("proc")?), &c("proc")?, Some(&c("proc")?), libc::MS_NOSUID | libc::MS_NODEV | libc::MS_NOEXEC, None)
        .map_err(|_| io_err("mount proc"))?;

    mkdir("dev")?;
    mount(Some(&c("tmpfs")?), &c("dev")?, Some(&c("tmpfs")?), libc::MS_NOSUID | libc::MS_NOEXEC, Some(&c("mode=755,size=1m")?))
        .map_err(|_| io_err("mount /dev tmpfs"))?;
    for node in ["null", "zero", "full", "random", "urandom", "tty"] {
        bind_dev(node);
    }

    mkdir("dev/pts")?;
    if mount(Some(&c("devpts")?), &c("dev/pts")?, Some(&c("devpts")?), libc::MS_NOSUID | libc::MS_NOEXEC, Some(&c("newinstance,ptmxmode=0666,mode=0666")?)).is_err() {
        eprintln!("pchroot: mount devpts failed (no pty)");
    } else {
        symlink("pts/ptmx", "dev/ptmx");
    }

    mkdir("dev/shm")?;
    if mount(Some(&c("tmpfs")?), &c("dev/shm")?, Some(&c("tmpfs")?), libc::MS_NOSUID | libc::MS_NODEV | libc::MS_NOEXEC, Some(&c("mode=1777,size=64m")?)).is_err() {
        eprintln!("pchroot: mount /dev/shm failed");
    }

    symlink("/proc/self/fd", "dev/fd");
    symlink("/proc/self/fd/0", "dev/stdin");
    symlink("/proc/self/fd/1", "dev/stdout");
    symlink("/proc/self/fd/2", "dev/stderr");

    mkdir("tmp")?;
    if mount(Some(&c("tmpfs")?), &c("tmp")?, Some(&c("tmpfs")?), libc::MS_NOSUID | libc::MS_NODEV, Some(&c("mode=1777,size=256m")?)).is_err() {
        eprintln!("pchroot: mount /tmp failed");
    }

    mkdir("sys")?; // intentionally left empty: host /sys is not exposed

    // user-defined extra binds; failure is a warning, same as the old module
    for (host, chroot_path) in &cfg.custom_mounts {
        let target = Path::new(chroot_path);
        let _ = std::fs::create_dir_all(target);
        let h = c(host)?;
        let t = c(chroot_path)?;
        if mount(Some(&h), &t, None, libc::MS_BIND, None).is_err() {
            eprintln!("Warning: failed to mount {host}");
        }
    }

    if unsafe { libc::sethostname(arch::HOSTNAME.as_ptr() as *const c_char, arch::HOSTNAME.len()) } != 0 {
        eprintln!("pchroot: sethostname failed");
    }
    Ok(())
}

fn pivot_into() -> Result<()> {
    let dot = c(".")?;
    let fd = unsafe { libc::open(dot.as_ptr(), libc::O_DIRECTORY | libc::O_RDONLY) };
    if fd < 0 {
        return Err(io_err("open rootfs"));
    }
    if unsafe { libc::fchdir(fd) } != 0 {
        return Err(io_err("fchdir rootfs"));
    }
    unsafe { libc::close(fd) };

    let rc = unsafe { libc::syscall(libc::SYS_pivot_root, dot.as_ptr(), dot.as_ptr()) };
    if rc != 0 {
        eprintln!("pchroot: pivot_root failed (EINVAL means initramfs root; report this)");
        return Err(io_err("pivot_root"));
    }
    mount(None, &dot, None, libc::MS_SLAVE | libc::MS_REC, None).map_err(|_| io_err("make-rslave"))?;
    if unsafe { libc::umount2(dot.as_ptr(), libc::MNT_DETACH) } != 0 {
        return Err(io_err("umount old root"));
    }
    let slash = c("/")?;
    if unsafe { libc::chdir(slash.as_ptr()) } != 0 {
        return Err(io_err("chdir /"));
    }
    Ok(())
}

// Capability bounding set trimmed to the Docker default set (0xa80425fb).
fn drop_caps() -> Result<()> {
    const KEEP: [i32; 14] = [
        libc::CAP_CHOWN, libc::CAP_DAC_OVERRIDE, libc::CAP_FSETID, libc::CAP_FOWNER,
        libc::CAP_MKNOD, libc::CAP_NET_RAW, libc::CAP_SETGID, libc::CAP_SETUID,
        libc::CAP_SETFCAP, libc::CAP_SETPCAP, libc::CAP_NET_BIND_SERVICE,
        libc::CAP_SYS_CHROOT, libc::CAP_KILL, libc::CAP_AUDIT_WRITE,
    ];
    for cap in 0..64 {
        if KEEP.contains(&cap) {
            continue;
        }
        let rc = unsafe { libc::prctl(libc::PR_CAPBSET_DROP, cap, 0, 0, 0) };
        if rc != 0 && std::io::Error::last_os_error().raw_os_error() != Some(libc::EINVAL) {
            return Err(io_err("PR_CAPBSET_DROP"));
        }
    }
    Ok(())
}

fn exec(cfg: &SandboxConfig) -> Result<i32> {
    let argv: Vec<CString> = match &cfg.command {
        Some(cmd) => cmd.iter().map(|a| c(a)).collect::<Result<_>>()?,
        None => vec![c("/bin/bash")?, c("-l")?],
    };
    let mut argv_ptr: Vec<*const c_char> = argv.iter().map(|a| a.as_ptr()).collect();
    argv_ptr.push(std::ptr::null());

    let env = [
        c("PATH=/usr/local/sbin:/usr/local/bin:/usr/bin")?,
        c(&format!("HOME={}", cfg.identity.home))?,
        c("LANG=C.UTF-8")?,
        c("TERM=xterm-256color")?,
    ];
    let mut env_ptr: Vec<*const c_char> = env.iter().map(|e| e.as_ptr()).collect();
    env_ptr.push(std::ptr::null());

    unsafe { libc::execve(argv_ptr[0], argv_ptr.as_ptr(), env_ptr.as_ptr()) };
    Err(io_err("execve"))
}

fn banner(cfg: &SandboxConfig) {
    let caps = if cfg.keep_caps { "all" } else { "docker" };
    let sec = if cfg.seccomp { "on" } else { "off" };
    match &cfg.command {
        Some(cmd) => eprintln!(
            "[pchroot] user={} cmd={} caps={} seccomp={}",
            cfg.identity.name, cmd[0], caps, sec
        ),
        None => eprintln!(
            "[pchroot] user={} uid={} caps={} seccomp={}",
            cfg.identity.name, cfg.identity.uid, caps, sec
        ),
    }
}

fn signal_ready(fd: i32) -> Result<()> {
    let b: [u8; 1] = [b'r'];
    if unsafe { libc::write(fd, b.as_ptr() as *const c_void, 1) } != 1 {
        return Err(io_err("signal ready"));
    }
    Ok(())
}

fn wait_go(fd: i32) -> bool {
    let mut b: [u8; 1] = [0];
    unsafe { libc::read(fd, b.as_mut_ptr() as *mut c_void, 1) } == 1
}

fn bind_dev(name: &str) {
    let src = format!("/dev/{name}");
    let dst = format!("dev/{name}");
    let (Ok(s), Ok(d)) = (c(&src), c(&dst)) else {
        return;
    };
    let fd = unsafe { libc::open(d.as_ptr(), libc::O_CREAT | libc::O_WRONLY, 0o666) };
    if fd >= 0 {
        unsafe { libc::close(fd) };
    }
    let _ = mount(Some(&s), &d, None, libc::MS_BIND, None);
}

fn mkdir(path: &str) -> Result<()> {
    let c_path = c(path)?;
    if unsafe { libc::mkdir(c_path.as_ptr(), 0o755) } != 0 {
        let e = std::io::Error::last_os_error();
        if e.raw_os_error() != Some(libc::EEXIST) {
            return Err(AppError::Io { what: format!("mkdir {path}"), source: e });
        }
    }
    Ok(())
}

fn symlink(target: &str, path: &str) {
    if let (Ok(t), Ok(p)) = (c(target), c(path)) {
        unsafe { libc::symlink(t.as_ptr(), p.as_ptr()) };
    }
}

fn mount(src: Option<&CString>, target: &CString, fstype: Option<&CString>, flags: libc::c_ulong, data: Option<&CString>) -> std::result::Result<(), ()> {
    let src_p = src.map(|s| s.as_ptr()).unwrap_or(std::ptr::null());
    let fst_p = fstype.map(|s| s.as_ptr()).unwrap_or(std::ptr::null());
    let data_p = data.map(|s| s.as_ptr()).unwrap_or(std::ptr::null());
    let rc = unsafe { libc::mount(src_p, target.as_ptr(), fst_p, flags, data_p as *const c_void) };
    if rc == 0 { Ok(()) } else { Err(()) }
}

fn c(s: &str) -> Result<CString> {
    CString::new(s).map_err(|_| AppError::InvalidArgs(format!("NUL byte in path: {s}")))
}

fn io_err(what: &str) -> AppError {
    AppError::Io { what: what.into(), source: std::io::Error::last_os_error() }
}
