pub mod cgroup;
pub mod child;
pub mod parent;
pub mod seccomp;

use std::ffi::c_void;
use std::io::Write;

use crate::arch;
use crate::error::{AppError, Result};

// cgroup v2 on the device only has the pids controller (see CHROOT_HANAMA 4.8).
pub const CGROUP_ROOT: &str = "/sys/fs/cgroup";
const STACK_SIZE: usize = 1 << 20;

#[derive(Clone)]
pub struct Identity {
    pub name: String,
    pub uid: u32, // uid inside the sandbox
    pub gid: u32,
    pub home: String,
}

impl Identity {
    pub fn root() -> Self {
        Identity { name: "root".into(), uid: 0, gid: 0, home: "/root".into() }
    }
}

pub struct SandboxConfig {
    pub net: bool,
    pub pids: u32, // 0 = no limit
    pub seccomp: bool,
    pub keep_caps: bool,
    pub custom_mounts: Vec<(String, String)>,
    pub identity: Identity,
    pub command: Option<Vec<String>>, // None -> interactive /bin/bash -l
}

// ndc firewall rules (CHROOT_HANAMA 4.6). Best effort: ndc failures are logged,
// never fatal. uid values are the real (host) uids Android's filter sees.
pub fn apply_firewall(uids: &[u32]) -> Result<()> {
    let mut log = std::fs::OpenOptions::new()
        .create(true)
        .append(true)
        .open(arch::LOG_FILE)
        .map_err(|e| AppError::Io { what: "open firewall log".into(), source: e })?;
    for uid in uids {
        for chain in ["dozable", "powersave", "restricted"] {
            let out = std::process::Command::new("ndc")
                .args(["firewall", "set_uid_rule", chain, &uid.to_string(), "allow"])
                .output();
            let line = match out {
                Ok(o) => format!(
                    "ndc {chain} {uid}: status={} stderr={}",
                    o.status,
                    String::from_utf8_lossy(&o.stderr)
                ),
                Err(e) => format!("ndc {chain} {uid}: spawn failed: {e}"),
            };
            writeln!(log, "{line}").map_err(|e| AppError::Io { what: "write firewall log".into(), source: e })?;
        }
    }
    let list: Vec<String> = uids.iter().map(u32::to_string).collect();
    println!("[pchroot] firewall rules applied for uid {} (see {})", list.join(", "), arch::LOG_FILE);
    Ok(())
}

pub fn read_custom_mounts() -> Vec<(String, String)> {
    std::fs::read_to_string(arch::CUSTOM_MOUNTS_FILE)
        .map(|s| {
            s.lines()
                .filter_map(|l| l.split_once('|').map(|(h, c)| (h.to_string(), c.to_string())))
                .collect()
        })
        .unwrap_or_default()
}

// clone with the namespace flags, then hand off to parent::supervise.
// The order of operations inside child::run is the core of the design and
// must not be rearranged (see CHROOT_HANAMA 4.4/4.5).
pub fn run(cfg: SandboxConfig) -> Result<i32> {
    let mut flags =
        libc::CLONE_NEWNS | libc::CLONE_NEWPID | libc::CLONE_NEWUTS | libc::CLONE_NEWIPC | libc::SIGCHLD;
    if cfg.net {
        flags |= libc::CLONE_NEWNET;
    }

    let (ready_r, ready_w) = pipe()?;
    let (go_r, go_w) = pipe()?;

    let pids = cfg.pids; // read before cfg moves into ChildStart
    let start = Box::new(child::ChildStart { cfg, ready_w, go_r });
    let start_ptr = Box::into_raw(start) as *mut c_void;

    let stack = unsafe {
        libc::mmap(
            std::ptr::null_mut(),
            STACK_SIZE,
            libc::PROT_READ | libc::PROT_WRITE,
            libc::MAP_PRIVATE | libc::MAP_ANONYMOUS | libc::MAP_STACK,
            -1,
            0,
        )
    };
    if stack == libc::MAP_FAILED {
        return Err(AppError::Io { what: "mmap stack".into(), source: std::io::Error::last_os_error() });
    }

    let pid = unsafe {
        libc::clone(
            child::trampoline,
            (stack as *mut u8).add(STACK_SIZE) as *mut c_void,
            flags,
            start_ptr,
        )
    };
    if pid < 0 {
        unsafe {
            libc::munmap(stack, STACK_SIZE);
        }
        return Err(AppError::Io { what: "clone".into(), source: std::io::Error::last_os_error() });
    }

    // Parent never uses the child ends.
    unsafe {
        libc::close(ready_w);
        libc::close(go_r);
    }

    let code = parent::supervise(pid, ready_r, go_w, pids)?;
    unsafe {
        libc::munmap(stack, STACK_SIZE);
    }
    Ok(code)
}

fn pipe() -> Result<(i32, i32)> {
    let mut fds = [0i32; 2];
    let rc = unsafe { libc::pipe(fds.as_mut_ptr()) };
    if rc != 0 {
        Err(AppError::Io { what: "pipe".into(), source: std::io::Error::last_os_error() })
    } else {
        Ok((fds[0], fds[1]))
    }
}
