use libc::c_void;

use crate::arch;
use crate::error::{AppError, Result};

use super::cgroup;

// Parent side: waits for the child to finish mounting, writes the uid/gid
// maps, joins the cgroup, releases the child, then waits and cleans up.
pub fn supervise(pid: i32, ready_r: i32, go_w: i32, pids: u32) -> Result<i32> {
    let mut byte = [0u8; 1];
    let n = unsafe { libc::read(ready_r, byte.as_mut_ptr() as *mut c_void, 1) };
    if n != 1 {
        // Child died before signalling ready; its own error is already printed.
        let _ = wait(pid);
        return Ok(1);
    }

    let mut cg = String::new();
    if pids > 0 {
        if let Err(e) = cgroup::join(pid, pids, &mut cg) {
            eprintln!("error: process limit setup failed ({e}); use --pids 0 to enter without a limit");
            unsafe { libc::kill(pid, libc::SIGKILL) };
            let _ = wait(pid);
            if !cg.is_empty() {
                cgroup::cleanup(&cg);
            }
            return Err(AppError::Cmd("process limit setup failed".into()));
        }
        eprintln!("[pchroot] pids.max={pids} (cgroup pcharch-{pid})");
    }

    let map_result = write_map(pid, "uid_map").and_then(|_| write_map(pid, "gid_map"));
    if let Err(e) = map_result {
        unsafe { libc::kill(pid, libc::SIGKILL) };
        let _ = wait(pid);
        if !cg.is_empty() {
            cgroup::cleanup(&cg);
        }
        return Err(e);
    }

    let g: [u8; 1] = [b'g'];
    unsafe {
        libc::write(go_w, g.as_ptr() as *const c_void, 1);
        libc::close(go_w);
    }

    let code = wait(pid)?;
    if !cg.is_empty() {
        cgroup::cleanup(&cg);
    }
    Ok(code)
}

fn write_map(pid: i32, name: &str) -> Result<()> {
    let path = format!("/proc/{pid}/{name}");
    std::fs::write(&path, format!("0 {} {}\n", arch::BASE, arch::RANGE))
        .map_err(|e| AppError::Io { what: format!("write {path}"), source: e })
}

fn wait(pid: i32) -> Result<i32> {
    let mut status = 0;
    loop {
        let r = unsafe { libc::waitpid(pid, &mut status, 0) };
        if r == pid {
            break;
        }
        let e = std::io::Error::last_os_error();
        if e.raw_os_error() != Some(libc::EINTR) {
            return Err(AppError::Io { what: "waitpid".into(), source: e });
        }
    }
    Ok(if libc::WIFEXITED(status) { libc::WEXITSTATUS(status) } else { 1 })
}
