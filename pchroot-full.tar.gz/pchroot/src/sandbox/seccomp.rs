use libc::c_void;

use crate::error::{AppError, Result};

// BPF instruction bits (linux/filter.h equivalents).
const BPF_LD: u16 = 0x00;
const BPF_W: u16 = 0x00;
const BPF_ABS: u16 = 0x20;
const BPF_JMP: u16 = 0x05;
const BPF_JEQ: u16 = 0x10;
const BPF_JSET: u16 = 0x40;
const BPF_K: u16 = 0x00;
const BPF_RET: u16 = 0x06;

// seccomp_data field offsets.
const OFF_NR: u32 = 0;
const OFF_ARCH: u32 = 4;
const OFF_ARGS0: u32 = 16;

// Common syscalls denied with EPERM. Present on both aarch64 and x86_64;
// anything arch-specific lives in ARCH_ONLY_* below.
const COMMON_EPERM: &[libc::c_long] = &[
    libc::SYS_kexec_load,
    libc::SYS_reboot,
    libc::SYS_init_module,
    libc::SYS_finit_module,
    libc::SYS_delete_module,
    libc::SYS_swapon,
    libc::SYS_swapoff,
    libc::SYS_mount,
    libc::SYS_umount2,
    libc::SYS_pivot_root,
    libc::SYS_unshare,
    libc::SYS_setns,
    libc::SYS_bpf,
    libc::SYS_perf_event_open,
    libc::SYS_userfaultfd,
    libc::SYS_keyctl,
    libc::SYS_add_key,
    libc::SYS_request_key,
    libc::SYS_name_to_handle_at,
    libc::SYS_open_by_handle_at,
    libc::SYS_kcmp,
    libc::SYS_acct,
    libc::SYS_settimeofday,
    libc::SYS_clock_settime,
    libc::SYS_clock_adjtime,
    libc::SYS_adjtimex,
    libc::SYS_syslog,
    libc::SYS_quotactl,
    libc::SYS_fanotify_init,
    libc::SYS_fsopen,
    libc::SYS_fsconfig,
    libc::SYS_fsmount,
    libc::SYS_fspick,
    libc::SYS_move_mount,
    libc::SYS_open_tree,
    libc::SYS_mount_setattr,
    libc::SYS_io_uring_setup,
    libc::SYS_io_uring_enter,
    libc::SYS_io_uring_register,
    libc::SYS_clone,
];

#[cfg(target_arch = "x86_64")]
const ARCH_ONLY_EPERM: &[libc::c_long] = &[
    libc::SYS_create_module,
    libc::SYS_query_module,
    libc::SYS_get_kernel_syms,
    libc::SYS_sysfs,
    libc::SYS_uselib,
    libc::SYS_stime,
    libc::SYS_nfsservctl,
    libc::SYS_lookup_dcookie,
    libc::SYS_iopl,
    libc::SYS_ioperm,
    libc::SYS_modify_ldt,
    libc::SYS_vm86,
    libc::SYS_vm86old,
];
#[cfg(target_arch = "aarch64")]
const ARCH_ONLY_EPERM: &[libc::c_long] = &[];

// clone3 -> ENOSYS so libc falls back to clone(), whose flags we can check.
const DENY_ENOSYS: &[libc::c_long] = &[libc::SYS_clone3];

#[cfg(target_arch = "aarch64")]
const AUDIT_ARCH: u32 = libc::AUDIT_ARCH_AARCH64;
#[cfg(target_arch = "x86_64")]
const AUDIT_ARCH: u32 = libc::AUDIT_ARCH_X86_64;

pub fn install() -> Result<()> {
    let mut f: Vec<libc::sock_filter> = Vec::with_capacity(64);
    let mut k = 0usize;
    let mut push = |code: u16, jt: u8, jf: u8, k_arg: u32, f: &mut Vec<libc::sock_filter>, n: &mut usize| {
        f.push(libc::sock_filter { code, jt, jf, k: k_arg });
        *n += 1;
    };

    push(BPF_LD | BPF_W | BPF_ABS, 0, 0, OFF_ARCH, &mut f, &mut k);
    push(BPF_JMP | BPF_JEQ | BPF_K, 1, 0, AUDIT_ARCH, &mut f, &mut k); // wrong arch -> kill
    push(BPF_RET | BPF_K, 0, 0, libc::SECCOMP_RET_KILL, &mut f, &mut k);
    push(BPF_LD | BPF_W | BPF_ABS, 0, 0, OFF_NR, &mut f, &mut k);

    for nr in COMMON_EPERM.iter().chain(ARCH_ONLY_EPERM) {
        push(BPF_JMP | BPF_JEQ | BPF_K, 0, 1, *nr as u32, &mut f, &mut k);
        push(BPF_RET | BPF_K, 0, 0, libc::SECCOMP_RET_ERRNO | libc::EPERM as u32, &mut f, &mut k);
    }
    for nr in DENY_ENOSYS {
        push(BPF_JMP | BPF_JEQ | BPF_K, 0, 1, *nr as u32, &mut f, &mut k);
        push(BPF_RET | BPF_K, 0, 0, libc::SECCOMP_RET_ERRNO | libc::ENOSYS as u32, &mut f, &mut k);
    }

    // clone() with CLONE_NEWUSER is denied; clone without it is allowed.
    push(BPF_JMP | BPF_JEQ | BPF_K, 0, 3, libc::SYS_clone as u32, &mut f, &mut k);
    push(BPF_LD | BPF_W | BPF_ABS, 0, 0, OFF_ARGS0, &mut f, &mut k);
    push(BPF_JMP | BPF_JSET | BPF_K, 0, 1, libc::CLONE_NEWUSER as u32, &mut f, &mut k);
    push(BPF_RET | BPF_K, 0, 0, libc::SECCOMP_RET_ERRNO | libc::EPERM as u32, &mut f, &mut k);
    push(BPF_RET | BPF_K, 0, 0, libc::SECCOMP_RET_ALLOW, &mut f, &mut k);

    let prog = libc::sock_fprog { len: k as u16, filter: f.as_ptr() };
    let rc = unsafe { libc::prctl(libc::PR_SET_SECCOMP, libc::SECCOMP_MODE_FILTER, &prog as *const _ as *const c_void) };
    if rc != 0 {
        return Err(AppError::Io { what: "seccomp".into(), source: std::io::Error::last_os_error() });
    }
    Ok(())
}
