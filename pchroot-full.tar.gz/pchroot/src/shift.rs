use std::ffi::CString;
use std::fs;
use std::os::unix::ffi::OsStrExt;
use std::os::unix::fs::MetadataExt;
use std::path::Path;

use crate::arch;
use crate::error::{AppError, Result};
use crate::heading;

// Port of do_shift() from sandbox.c. Depth-first (children before directory,
// FTW_DEPTH), never follows symlinks (FTW_PHYS), never crosses filesystems
// (FTW_MOUNT). The base directory is processed last, so its owner marks the
// resumable state: rerun the same command after an interruption.

pub fn run(shift: bool) -> Result<i32> {
    println!("{}", heading("ARCH", if shift { "SHIFT" } else { "UNSHIFT" }));
    println!();

    if !Path::new(arch::SHIFT_MARKER).exists() {
        return Err(AppError::InvalidArgs(
            "refusing: marker rootfs/.sandbox-copy is missing; create it on purpose first".into(),
        ));
    }

    let dir = arch::rootfs();
    let meta = fs::metadata(dir).map_err(|e| AppError::Io {
        what: format!("stat {}", dir.display()),
        source: e,
    })?;
    let owner = meta.uid();
    if shift && owner >= arch::BASE {
        return Err(AppError::InvalidArgs(format!(
            "{dir} already shifted (owner {owner}); nothing to do"
        )));
    }
    if !shift && owner < arch::BASE {
        return Err(AppError::InvalidArgs(format!(
            "{dir} not shifted yet (owner {owner}); nothing to undo"
        )));
    }

    let base_dev = meta.dev();
    let mut moved: u64 = 0;
    walk_children(dir, base_dev, shift, &mut moved)?;
    // Base directory itself, last: its owner becomes the resume marker.
    chown_one(dir, &meta, shift, &mut moved)?;

    println!(
        "done: {moved} entries {}",
        if shift { "+100000" } else { "-100000" }
    );
    if !shift {
        println!("note: setuid bits and file capabilities were dropped at shift;");
        println!("restore them from a classic chroot: pacman -S sudo util-linux shadow iputils");
    }
    Ok(0)
}

fn walk_children(dir: &Path, base_dev: u64, shift: bool, moved: &mut u64) -> Result<()> {
    let rd = fs::read_dir(dir).map_err(|e| AppError::Io {
        what: format!("read_dir {}", dir.display()),
        source: e,
    })?;
    for entry in rd {
        let entry = entry.map_err(|e| AppError::Io {
            what: format!("read_dir {}", dir.display()),
            source: e,
        })?;
        let path = entry.path();
        let meta = fs::symlink_metadata(&path).map_err(|e| AppError::Io {
            what: format!("lstat {}", path.display()),
            source: e,
        })?;
        if meta.dev() != base_dev {
            continue; // do not cross into other filesystems (e.g. leftover mounts)
        }
        if meta.file_type().is_dir() {
            walk_children(&path, base_dev, shift, moved)?; // contents first
        }
        chown_one(&path, &meta, shift, moved)?;
    }
    Ok(())
}

fn chown_one(path: &Path, meta: &fs::Metadata, shift: bool, moved: &mut u64) -> Result<()> {
    let (u, g) = (meta.uid(), meta.gid());
    let (nu, ng) = if shift {
        (
            if u < arch::BASE { u + arch::BASE } else { u },
            if g < arch::BASE { g + arch::BASE } else { g },
        )
    } else {
        (
            if (arch::BASE..arch::BASE + arch::RANGE).contains(&u) {
                u - arch::BASE
            } else {
                u
            },
            if (arch::BASE..arch::BASE + arch::RANGE).contains(&g) {
                g - arch::BASE
            } else {
                g
            },
        )
    };
    if nu == u && ng == g {
        return Ok(());
    }
    let c_path = CString::new(path.as_os_str().as_bytes()).map_err(|_| {
        AppError::InvalidArgs(format!("path contains NUL: {}", path.display()))
    })?;
    // lchown: does not follow symlinks, matches the C version.
    let rc = unsafe { libc::lchown(c_path.as_ptr(), nu, ng) };
    if rc != 0 {
        // Same as nftw returning 1: stop; rerunning continues where it stopped.
        return Err(AppError::Cmd(format!(
            "lchown {}: {}; stopped midway, rerun the same command",
            path.display(),
            std::io::Error::last_os_error()
        )));
    }
    *moved += 1;
    Ok(())
}
