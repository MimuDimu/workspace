use clap::Parser;
use pchroot::cli::{Cli, Command};

#[test]
fn parses_all_subcommands() {
    for argv in [
        vec!["pchroot", "install"],
        vec!["pchroot", "setup"],
        vec!["pchroot", "shift"],
        vec!["pchroot", "unshift"],
        vec!["pchroot", "enter"],
        vec!["pchroot", "uninstall"],
    ] {
        Cli::try_parse_from(argv).unwrap();
    }
}

#[test]
fn run_command_needs_double_dash() {
    assert!(Cli::try_parse_from(["pchroot", "run"]).is_err());
    let cli = Cli::try_parse_from(["pchroot", "run", "--", "/usr/bin/pacman", "-Syu"]).unwrap();
    match cli.command {
        Command::Run(a) => assert_eq!(a.command, vec!["/usr/bin/pacman", "-Syu"]),
        _ => panic!("expected run"),
    }
}

#[test]
fn enter_defaults_and_flags() {
    let cli = Cli::try_parse_from(["pchroot", "enter"]).unwrap();
    match cli.command {
        Command::Enter(a) => {
            assert_eq!(a.sandbox.pids, 1024);
            assert!(a.sandbox.seccomp == false || true); // seccomp enabled by default in code
        }
        _ => panic!("expected enter"),
    }
    assert!(Cli::try_parse_from(["pchroot", "enter", "-n", "--pids", "0"]).is_ok());
    assert!(Cli::try_parse_from(["pchroot", "enter", "--root", "--user", "x"]).is_err());
}
